class Transaction {
  final String title;
  final double price;
  final DateTime dateTime;

  Transaction(
      {required this.dateTime, required this.price, required this.title});
}
