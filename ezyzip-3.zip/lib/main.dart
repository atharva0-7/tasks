import './transactions.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyHomePage());
}

class MyHomePage extends StatelessWidget {
  List<Transaction> transactions = [
    Transaction(dateTime: DateTime.now(), price: 100, title: "Shoes"),
    Transaction(dateTime: DateTime.now(), price: 200, title: "Food")
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          appBar: AppBar(
            title: Text("Budget Check"),
          ),
          body: Column(
            children: transactions.map((trans) {
              return Card(
                child: Text(trans.title),
              );
            }).toList(),
          )),
    );
  }
}
